using System.Globalization;
using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using AscendAPP.Core.Combat;

namespace FooMeter.Linux;

public sealed class MeterWindow : Window
{
    private readonly LinuxMeter _meter = new(Program.Demo);
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(500) };
    private readonly ComboBox _devices = new() { MinWidth = 180, MaxWidth = 320, PlaceholderText = "Choose adapter" };
    private readonly TextBlock _status = Label("", 11);
    private readonly TextBlock _summary = Label("Waiting for combat", 15);
    private readonly ListBox _players = new();
    private readonly TextBlock _skills = Label("Select a player for skill damage, healing and critical hits.", 12);
    private readonly TextBlock _events = Label("", 13);
    private readonly TextBlock _pets = Label("", 12);
    private readonly TextBox _petSearch = new() { Watermark = "Search pets", Margin = new(0, 0, 0, 8) };
    private readonly ListBox _history = new();
    private readonly TextBlock _historyDetails = Label("Select a saved encounter.", 12);
    private readonly TextBlock _diagnostics = Label("", 11);
    private readonly TextBlock _error = Label("", 12);
    private EncounterSnapshot? _fight;
    private uint? _selectedActor;
    private Guid? _selectedHistory;
    private string[] _deviceRows = [];
    private bool _closing;
    private bool _busy;

    private static TextBlock Label(string text, double size) => new()
    { Text = text, FontSize = size, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.WhiteSmoke };

    public MeterWindow()
    {
        Title = "FooMeter Linux";
        Width = 470; Height = 520; MinWidth = 360; MinHeight = 300;
        FontSize = 12;
        Background = new SolidColorBrush(Color.Parse("#191D26"));
        var root = new DockPanel { Margin = new(12), LastChildFill = true };
        var header = new StackPanel { Spacing = 8 };
        header.Children.Add(Label(Program.Demo ? "FooMeter · Linux preview · DEMO" : "FooMeter · Linux preview", 18));
        var toolbar = new WrapPanel { Orientation = Orientation.Horizontal };
        toolbar.Children.Add(_devices);
        toolbar.Children.Add(Button("Refresh", async () => await LoadDevices()));
        toolbar.Children.Add(Button("Start", async () =>
        {
            if (_devices.SelectedIndex < 0) throw new InvalidOperationException("Choose a capture adapter first.");
            string line = _deviceRows[_devices.SelectedIndex];
            // dumpcap -D: "1. enp4s0 (description)". Pass the interface name rather than an unstable index.
            string name = line[(line.IndexOf(". ", StringComparison.Ordinal) + 2)..].Split(' ', 2)[0];
            await _meter.Start(name);
        }));
        toolbar.Children.Add(Button("Stop", () => _meter.Stop()));
        toolbar.Children.Add(Button("New fight", () => { _meter.Reset(); return Task.CompletedTask; }));
        var topmost = new CheckBox { Content = "Keep above", IsChecked = false, Margin = new(6) };
        topmost.IsCheckedChanged += (_, _) => Topmost = topmost.IsChecked == true;
        toolbar.Children.Add(topmost);
        header.Children.Add(toolbar); header.Children.Add(_status); header.Children.Add(_error); header.Children.Add(_summary);
        DockPanel.SetDock(header, Dock.Top); root.Children.Add(header);

        _players.SelectionChanged += (_, _) =>
        {
            if (_players.SelectedItem is PlayerRow row) _selectedActor = row.Id;
            UpdateSkills();
        };
        _history.SelectionChanged += (_, _) =>
        {
            if (_history.SelectedItem is HistoryRow row)
            {
                _selectedHistory = row.Fight.Id;
                _historyDetails.Text = $"{row.Fight.TargetName} · {row.Fight.DurationSeconds:N1}s\n" +
                    string.Join("\n", row.Fight.Players.Select(p => $"{p.Name}: {p.Damage:N0} damage · {p.Dps:N0} DPS · {p.Healing:N0} healing"));
            }
        };
        var combat = new Grid { RowDefinitions = new("*,Auto"), Margin = new(0, 10, 0, 0) };
        combat.Children.Add(_players); Grid.SetRow(_skills, 1); combat.Children.Add(_skills);
        var petPanel = new DockPanel(); DockPanel.SetDock(_petSearch, Dock.Top);
        petPanel.Children.Add(_petSearch); petPanel.Children.Add(Scroll(_pets));
        var historyPanel = new Grid { RowDefinitions = new("*,Auto") };
        historyPanel.Children.Add(_history); Grid.SetRow(_historyDetails, 1); historyPanel.Children.Add(_historyDetails);
        root.Children.Add(new TabControl
        {
            Margin = new(0, 10, 0, 0),
            ItemsSource = new TabItem[]
            {
                new() { Header = "Combat", FontSize = 13, Content = combat },
                new() { Header = "Events", FontSize = 13, Content = Scroll(_events) },
                new() { Header = "Pets", FontSize = 13, Content = petPanel },
                new() { Header = "History", FontSize = 13, Content = historyPanel },
                new() { Header = "Info", FontSize = 13, Content = Scroll(_diagnostics) }
            }
        });
        Content = root;
        _timer.Tick += (_, _) => Paint();
        Opened += async (_, _) =>
        {
            Paint(); _timer.Start();
            if (Program.SmokePath is { } path)
            {
                await Task.Delay(700);
                try
                {
                    var view = _meter.View();
                    if (view.Fight.TotalDamage != 20000 || _players.ItemCount != 2) throw new InvalidOperationException("UI did not render demo combat.");
                    using var bitmap = new RenderTargetBitmap(new PixelSize((int)Bounds.Width, (int)Bounds.Height));
                    bitmap.Render(this); bitmap.Save(Path.ChangeExtension(path, ".png"));
                    File.WriteAllText(path, JsonSerializer.Serialize(new { Passed = true, Players = _players.ItemCount,
                        view.Fight.TotalDamage, Events = view.Events.Count, Pets = view.Pets.Count }));
                }
                catch (Exception e) { File.WriteAllText(path, JsonSerializer.Serialize(new { Passed = false, Error = e.ToString() })); Environment.ExitCode = 1; }
                Close();
            }
            else if (!Program.Demo) await LoadDevices();
        };
        Closing += async (_, e) =>
        {
            if (_closing) return;
            e.Cancel = true; _closing = true; _timer.Stop();
            try { await _meter.Stop(); _meter.Dispose(); }
            catch (Exception error) { Console.Error.WriteLine("Saving profile: " + error.Message); }
            Close();
        };
    }

    private static ScrollViewer Scroll(Control control) => new() { Content = control, Margin = new(0, 8, 0, 0) };
    private Button Button(string label, Func<Task> action)
    {
        var button = new Button { Content = label, Margin = new(3), Padding = new(8, 5) };
        button.Click += async (_, _) =>
        {
            if (_busy || _closing) return;
            _busy = true; _error.Text = "";
            try { await action(); }
            catch (Exception e) { _error.Text = e.Message + "\nSee Info for Linux capture setup."; }
            finally { _busy = false; Paint(); }
        };
        return button;
    }
    private async Task LoadDevices()
    {
        try { _deviceRows = await LinuxMeter.Devices(); _devices.ItemsSource = _deviceRows; _devices.SelectedIndex = _deviceRows.Length > 0 ? 0 : -1; }
        catch (Exception e) { _error.Text = "Cannot list adapters: " + e.Message + "\nInstall wireshark-cli and enable dumpcap for your user; see README-LINUX.md."; }
    }
    private void Paint()
    {
        var view = _meter.View(); _fight = view.Fight;
        _status.Text = view.Status;
        _summary.Text = $"{_fight.TargetName ?? "Waiting for combat"} · {_fight.DurationSeconds:N0}s\n" +
            $"{_fight.PartyDps:N0} DPS · {_fight.TotalDamage:N0} damage · {_fight.TotalHealing:N0} healing";
        _players.ItemsSource = _fight.Players.Select(p =>
        {
            var rating = view.Ratings.GetValueOrDefault(p.ActorId);
            return new PlayerRow(p.ActorId, $"{(p.IsSelf ? "★ " : "")}{p.Name} · {p.ClassName ?? "Unknown class"}\n" +
                $"{p.Dps:N0} DPS · {p.Damage:N0} damage · {p.Share:P0} · GS {rating?.GearScore?.ToString() ?? "?"} / CP {rating?.CombatPower?.ToString() ?? "?"}");
        }).ToArray();
        _players.SelectedItem = _players.Items.Cast<PlayerRow>().FirstOrDefault(p => p.Id == _selectedActor);
        UpdateSkills();
        var now = DateTimeOffset.UtcNow;
        string Countdown(DateTimeOffset at) => (at > now ? at - now : TimeSpan.Zero).ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture);
        _events.Text = string.Join("\n\n", view.Events.Select(e => $"{e.Event.Name}{(e.Event.Possible ? " (possible)" : "")} · {(e.InWindow ? "ends" : "starts")} in {Countdown(e.CountdownAt)}")) +
            "\n\nField bosses · open the game's boss list to synchronize\n\n" + string.Join("\n\n", view.Bosses.Select(b =>
                $"{b.Boss.Name} · {(b.Observation is null ? "Unknown" : b.Observation.Alive ? "Observed alive" : b.Due is { } due ? Countdown(due) : "Unknown respawn")}"));
        _pets.Text = view.PetStatus + "\n\n" + string.Join("\n", view.Pets.Where(p => p.Name.Contains(_petSearch.Text ?? "", StringComparison.OrdinalIgnoreCase))
            .Select(p => $"{p.Name} · level {p.Level?.ToString() ?? "?"} · {p.Progress}"));
        _history.ItemsSource = view.History.Select(f => new HistoryRow(f, $"{f.StartedAt.ToLocalTime():MM-dd HH:mm} · {f.TargetName}\n{f.TotalDamage:N0} damage · {f.DurationSeconds:N0}s")).ToArray();
        _history.SelectedItem = _history.Items.Cast<HistoryRow>().FirstOrDefault(h => h.Fight.Id == _selectedHistory);
        _diagnostics.Text = view.Diagnostics.Summary + "\n\n" + view.Identity + "\n\n" + view.HistoryStatus + "\n\nProfile: " + _meter.ProfileDirectory +
            "\n\nLinux preview based on FooMeter 0.10.29. Uses dumpcap and XWayland. Start capture before entering your character. Only self/confirmed party damage to recognized bosses and training dummies is admitted. Healing is the shared core's HP-based estimate." +
            "\n\nCapture: install wireshark-cli and enable dumpcap access for your user (README-LINUX.md). Never launch this UI with sudo." +
            "\n\nNot ported: loot-row OCR, click-through/Alt interaction, global hotkeys, Windows updates, appearance settings and exports. Hyprland rules control floating/pinning; Keep above alone may be overridden by your compositor.";
    }
    private void UpdateSkills()
    {
        var player = _fight?.Players.FirstOrDefault(p => p.ActorId == _selectedActor);
        _skills.Text = player is null ? "Select a player for skill details." : $"{player.Name} · crit {player.CritRate:P1}\n" +
            string.Join("\n", player.Skills.OrderByDescending(s => s.Damage).Take(12).Select(s =>
                $"{s.Name ?? $"Skill #{s.SkillId}"}: {s.Damage:N0} damage · {s.Healing:N0} healing · {s.Hits} hits / {s.CriticalHits} crits"));
    }
    private sealed record PlayerRow(uint Id, string Text) { public override string ToString() => Text; }
    private sealed record HistoryRow(EncounterSnapshot Fight, string Text) { public override string ToString() => Text; }
}
