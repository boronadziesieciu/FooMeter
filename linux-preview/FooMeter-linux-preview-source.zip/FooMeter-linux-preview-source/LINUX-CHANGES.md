# Linux preview changes

The uploaded FooMeter 0.10.29 source is retained as the base. The release README,
START-HERE.txt and VERIFICATION.json describe the original Windows release, not
this Linux preview. Use README-LINUX.md and the following results for Linux.

- Added src/FooMeter.Linux: Avalonia frontend and dumpcap-based capture adapter.
- Added bounded classic pcap reading to the shared core.
- Added Linux SLL/SLL2 packet header support to the existing TCP extractor.
- Added LinuxCaptureChecks to the existing self-test runner.
- Added a separate Linux solution, build/package script and non-root launcher.
- Original Windows UI source and solution are unchanged.

Validation in the cloud Linux environment:

- Linux build: zero warnings, zero errors.
- Core suite: all 555 checks passed (541 original checks plus 14 new checks).
- Model smoke: synthetic combat, three event schedules and 207 pet definitions.
- X11 window smoke: two synthetic players rendered; screenshot and JSON saved.
- Real dumpcap integration: adapter enumeration and failed-capture lifecycle.
- Self-contained linux-x64 distribution: model and X11 window smoke checks.

Live packet capture is unavailable to this cloud user's privileges. No game is
installed here. Current Aion 2 traffic, CachyOS capture permissions, Hyprland
stacking and interaction have not been validated. Existing protocol tests use
synthetic fixtures. The initial Linux interface omits several Windows features;
README-LINUX.md lists them explicitly.
